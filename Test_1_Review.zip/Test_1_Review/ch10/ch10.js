// Chapter 10
// HTML forms
// post vs get

// Html5 form validation vs javascript / JQuery form validation
// val, trim, 

// focus(), - focus on the elemetn
// blur() - remove the focus 
//submit() - submit form
//trim(); - trim the white space from the input
// Understand the basic steps for validating a form with Javascript and JQuery

//TODO: try a method get for forms - hides password info


