// Chapter 7
// -Preload images

// const allImages = $("#image_list").querySelectorAll();
// for ( let link of allImages ) {
        
//     // preload image
//     const image = new Image();
//     image.src = link.href;
    

// -Use one time timers (setTimeout, clearTimeout)
//timer = setTimeout( callfunction, 5000 )
//clearTimeout( timer );

// -Use interval timers (setInterval, clearInterval)
//timer  = setInterval( goToTerms, 1000 );
//    clearInterval( timer );


// -Properties of HTML img element (src, alt, width, height)
//img have src and alt
//a has href
