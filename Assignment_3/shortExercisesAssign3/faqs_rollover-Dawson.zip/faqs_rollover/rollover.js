$(document).ready(() => {
    
    $("#faq_rollovers li").each( (index, elem)=>{
        $(elem[index]).hover(
            function() {
                $("p").show()
            }, function(){
                $("p").hide()

            }
        );
    });
    


}); // end ready