# Say.js
## Say anything!

With Say.js you can say anything with a computer synthesiser. All you need to do is:

`say(msg);`

Here is the code link:

https://rawgit.com/JudahRR/Say.js/master/libs/say.js
