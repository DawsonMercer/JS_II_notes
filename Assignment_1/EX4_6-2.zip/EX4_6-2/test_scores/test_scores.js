"use strict";
const $ = selector => document.querySelector(selector);

const names = ["Ben", "Joel", "Judy", "Anne"];
const scores = [88, 98, 77, 88];

const results = $("#results");


let addScore = () =>{
	//TODO: add please enter a name
	//TODO: add score between 0 and 100
	let name = $("#name");
	let score = $("#score");

	let isValid = true;
	
	if (name.value == "" || score.value == ""){
		isValid = false;
		alert("If you wish to submit a grade please fill out both fields");
	}
	if (score.value < 0 || score.value > 100 || isNaN(score.value)){
		isValid = false;
		window.alert("Enter a valid score between 0-100");
	}

	if(isValid == true){
        names.push(name.value);
		scores.push(parseInt(score.value));
    }

}

let displayResults = () =>{
	//TODO: check to seee if the div has text content, if not add Results and do calc
	
	//add h2 element
	const h2 = document.createElement('h2');
	h2.setAttribute("id", "results_h2");
	results.append(h2)

	//then add the etxt for it "Results"
	h2.textContent = "Results";
	let total = 0;
	let highestGrade = 0;
	let highestGradesName = 0;
	for(let score of scores){
		total +=score;
		if(score > highestGrade){
			highestGrade = score;
			highestGradesName = scores.indexOf(score);
		}
	}
	let average = total/scores.length;
	
	const p = document.createElement('p');
	const p2 = document.createElement('p');
	const h2Element = $("#results_h2");
	h2Element.after(p);
	p.after(p2);
	console.log(names);
	console.log(scores)
	p.textContent = (`Average Score = ${average}`);
	p2.textContent= (`High score = ${names[highestGradesName]} with a score of ${scores[highestGradesName]}`);
	

}

document.addEventListener("DOMContentLoaded", () => {
	$("#name").focus();
	// add event handlers
	$("#add").addEventListener("click", addScore);
	$("#display_results").addEventListener("click", displayResults);
	//FIXME:$("#display_scores").addEventListener("click", displayScores);
});